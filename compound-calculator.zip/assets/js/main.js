document.getElementById('calculateBtn').addEventListener('click', function() {
    const principal = parseFloat(document.getElementById('principal').value);
    const rate = parseFloat(document.getElementById('rate').value) / 100;
    const times = parseFloat(document.getElementById('times').value);
    const years = parseFloat(document.getElementById('years').value);

    if (isNaN(principal) || isNaN(rate) || isNaN(times) || isNaN(years)) {
        document.getElementById('result').textContent = "Please fill all fields correctly.";
        return;
    }

    const amount = principal * Math.pow((1 + rate / times), times * years);
    document.getElementById('result').textContent = `Future Value: $${amount.toFixed(2)}`;
});
